import React from 'react'

export default class Education extends React.Component {

    render(){

        return (
            <fieldset>
            <h2 className="fs-title">Education &amp; Qualifications</h2>
            <h3 className="fs-subtitle mb-5">Educational Institutions attended and qualifications obtained</h3>
            <div className="row text-left mb-5">
                <div className="col-md-6">
                    <div className="form-group">
                        <label htmlFor="text-input" className="form-control-label">Institution Attended</label>
                        <input className="form-control" type="text" id="text-input" />
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="form-group">
                        <label htmlFor="text-input" className="form-control-label">Graduation Year</label>
                        <input className="form-control" type="text" id="text-input" />
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="form-group">
                        <label htmlFor="text-input" className="form-control-label">Qualification Obtained</label>
                        <input className="form-control" type="text" id="text-input" />
                    </div>
                </div>
                <div className="col-md-6">
                    <button className="btn btn-icon btn-3 btn-primary btn-sm" type="button">
                        <span className="btn-inner--icon"><i className="fa fa-plus" /></span>
                        <span className="btn-inner--text">Add qualification</span>
                    </button>
                </div>
            </div>
            <input type="button" name="previous" className="previous action-button-previous" defaultValue="Previous" />
            <input type="button" name="next" className="next action-button" defaultValue="Next" />
        </fieldset>

        )
    }
}