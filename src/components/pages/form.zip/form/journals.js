import React from 'react'

export default class Journals extends React.Component {
    state = {
        show:false
    }
    render(){

        return (

            <fieldset>
            <h2 className="fs-title">Journals &amp; Publications</h2>
            <h3 className="fs-subtitle mb-5">Journals, research or other published work</h3>
            <div className="border-bottom">
                <div className="form-group text-left">
                    <h5>I have journals or other published work &nbsp;</h5>
                    <h5>
                        <label className="custom-toggle" onclick="showThisForm('publications')">
                            <input type="checkbox" value={this.state.show} onChange={() => this.setState({show:!this.state.show})} />
                            <span className="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes" />
                        </label>
                    </h5>
                </div>
            </div>
            {
                    this.state.show
                    ?
            <div className="row text-left mt-3 mb-5" id="publications" >
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="text-input" className="form-control-label">Institution</label>
                            <input className="form-control" type="text" id="text-input" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="text-input" className="form-control-label">Year of Publication</label>
                            <input className="form-control" type="text" id="text-input" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="text-input" className="form-control-label">Name of Publisher</label>
                            <input className="form-control" type="text" id="text-input" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="text-input" className="form-control-label">Qualification</label>
                            <input className="form-control" type="text" id="text-input" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <button className="btn btn-icon btn-3 btn-primary btn-sm" type="button">
                            <span className="btn-inner--icon"><i className="fa fa-plus" /></span>
                            <span className="btn-inner--text">Add publication</span>
                        </button>
                    </div>
            </div>
                : null
            }
            <input type="button" name="previous" className="previous action-button-previous" defaultValue="Previous" />
            <input type="button" name="next" className="next action-button" defaultValue="Next" />
        </fieldset>

        )
    }

}