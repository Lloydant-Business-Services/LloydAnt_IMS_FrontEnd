import React from 'react'

export default class Referee extends React.Component {
    
    
    render() {

        return (
            <fieldset>
                <h2 className="fs-title">Referees </h2>

                {
                    
                      <div className="text-left mt-3" id="referees" >
                      <div className="bg-primary text-center" style={{ borderRadius: '25px', width: '30px' }}>
                          <p className="text-white">1</p>
                      </div>
                      <div className="row text-left mt-0 mb-5 ml-3 border-bottom">
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Name of Referee</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Organisation</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Designation</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Email</label>
                                  <input className="form-control" type="email" id="text-input" />
                              </div>
                          </div>
                      </div>
                      <div className="bg-primary text-center" style={{ borderRadius: '25px', width: '30px' }}>
                          <p className="text-white">2</p>
                      </div>
                      <div className="row text-left mt-0 mb-5 ml-3 border-bottom">
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Name of Referee</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Organisation</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Designation</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Email</label>
                                  <input className="form-control" type="email" id="text-input" />
                              </div>
                          </div>
                      </div>
                      <div className="bg-primary text-center" style={{ borderRadius: '25px', width: '30px' }}>
                          <p className="text-white">3</p>
                      </div>
                      <div className="row text-left mt-0 mb-5 ml-3 border-bottom">
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Name of Referee</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Organisation</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Designation</label>
                                  <input className="form-control" type="text" id="text-input" />
                              </div>
                          </div>
                          <div className="col-md-6">
                              <div className="form-group">
                                  <label htmlFor="text-input" className="form-control-label">Email</label>
                                  <input className="form-control" type="email" id="text-input" />
                              </div>
                          </div>
                      </div>
                  </div>
                  
                }
                <input type="button" name="previous" className="previous action-button-previous" defaultValue="Previous" />
                <input type="submit" name="submit" className="submit action-button" defaultValue="Submit" />
            </fieldset>

        )
    }
}