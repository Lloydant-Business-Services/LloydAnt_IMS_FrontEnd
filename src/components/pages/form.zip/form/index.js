import React from "react";
import favicon from "../../../images/brand/favicon.png";
import nucleo from "../../../styles/vendor/nucleo/css/nucleo.css";
import fontawesome from "../../../styles/vendor/@fortawesome/fontawesome-free/css/all.min.css";
// import 'bootstrap/dist/js/bootstrap.bundle.min';
import { graphql, Link, withPrefix } from "gatsby";
import "./form.css"
import Education from "./educationalQualification";
import ProfessionalBody from "./professionalBody";
import WorkExperience from "./work";
import Journals from "./journals";
import Research from "./research";
import Certication from "./certifications";
import Referee from "./referee";
import logosm from "../../../images/ziklogosml.png"
import logobg from "../../../images/ziklogo.png"

export default class FormIndex extends React.Component {

    handleNextClick = (e) => {

        var current_fs, next_fs; //fieldsets
        var animating; //flag to prevent quick multi-click glitches

        if (animating) return false;
        animating = true;

        current_fs = e.target.parentNode; // get the current element holding the button clicked
        next_fs = e.target.parentNode.nextSibling; // get the next element

        //get the index of the next element so we can update the progress bar
        var index = Array.prototype.indexOf.call(document.getElementsByTagName('fieldset'), next_fs);

        //Get all progresbar elements and activate the next one
        const progressBar = document.getElementById('progressbar');
        if (progressBar) {
            const allBars = progressBar.getElementsByTagName('li');
            allBars[index].classList.add('active');
        }

        //show the next element
        next_fs.style.display = 'block';

        current_fs.animate([
            // keyframes
            { transform: 'rotate(0) translate3D(-50%, -50%, 0', color: '#000' },
            { color: '#431236', offset: 0.3 },
            { transform: 'rotate(360deg) translate3D(-50%, -50%, 0)', color: '#000' }

        ], {
            // timing options
            duration: 800,
            iterations: 1
        });
        current_fs.style.display = 'none';

    }

    handlePreviousClick = (e) => {

        var current_fs, previous_fs; //fieldsets
        var animating; //flag to prevent quick multi-click glitches

        if (animating) return false;
        animating = true;

        current_fs = e.target.parentNode; // get the current element holding the button clicked
        previous_fs = e.target.parentNode.previousSibling; // get the next element

        //get the index of the next element so we can update the progress bar
        var index = Array.prototype.indexOf.call(document.getElementsByTagName('fieldset'), current_fs);

        //Get all progresbar elements and activate the next one
        const progressBar = document.getElementById('progressbar');
        if (progressBar) {
            const allBars = progressBar.getElementsByTagName('li');
            allBars[index].classList.remove('active');
        }

        //show the next element
        previous_fs.style.display = 'block';


        current_fs.style.display = 'none';
    }

    componentDidMount() {

        const nextButtons = document.getElementsByClassName('next');
        for (let index = 0; index < nextButtons.length; index++) {
            const element = nextButtons[index];
            element.addEventListener('click', this.handleNextClick);
        }

        const previousButtons = document.getElementsByClassName('previous');
        for (let index = 0; index < previousButtons.length; index++) {
            const element = previousButtons[index];
            element.addEventListener('click', this.handlePreviousClick);
        }

    }

    render() {
        return (
            <div>
                <header>
                    <meta charSet="utf-8" />
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
                    {/* Favicon */}
                    <link rel="icon" href={favicon} type="image/png" />
                    {/* Fonts */}
                    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" />
                    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&display=swap" rel="stylesheet" />
                    {/* Icons */}
                    <link rel="stylesheet" href={nucleo} type="text/css" />
                    <link rel="stylesheet" href={fontawesome} type="text/css" />
                    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" />
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" />
        <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossOrigin="anonymous"></script>
                    {/* <link rel="stylesheet" href="../assets/css/style.css" type="text/css"> */}

                </header>

                <div className="main-content" id="panel">


                    <nav className="navbar navbar-top navbar-expand navbar-light m-0 p-0" style={{backgroundColor: "#253b80"}}> 
                        <div className="container">
                            <div className="collapse navbar-collapse" id="navbarSupportedContent">
                                {/* Navbar links */} 

                                    <a className="navbar-brand" href="dashboard.html" style={{display: "inline-block"}}>
                                        {/* <img src="assets/img/brand/blue.png" class="navbar-brand-img" alt="..."> */}
                                        {/* <h2 className="mb-0 text-white pop-font">HRM</h2>  */}
                                        <span className="avatar avatar-sm" style={{backgroundColor: "transparent"}}>
                                            <img src={logosm} className="pt-5" /> 
                                        </span>
                                    </a>

                                <ul className="navbar-nav align-items-center ml-md-auto">


                                    <li className="nav-item d-xl-none">
                                        {/* Sidenav toggler */}
                                        <div className="pr-3 sidenav-toggler sidenav-toggler-light" data-action="sidenav-pin" data-target="#sidenav-main">
                                            <div className="sidenav-toggler-inner">
                                                <i className="sidenav-toggler-line" />
                                                <i className="sidenav-toggler-line" />
                                                <i className="sidenav-toggler-line" />
                                            </div>
                                        </div>
                                    </li>

                                    <li className="nav-item">
                                        <Link className="nav-link" to="/pages/login" > 
                                            <button className="btn btn-accent">Sign In</button>
                                        </Link>
                                    </li>

                                </ul>

                            </div>
                        </div>
                    </nav>

                    <div>

                        <div className="header pb-6">
                            <div className="container">

                            </div>
                            {/* Page content */}
                            <div className="container">
                                <div className>
                                    <div className="card" style={{ minHeight: '100vh' }}>
                                        <div className="card-body">
                                            {/* MultiStep Form */}
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <form id="msform">
                                                        {/* progressbar */}
                                                        <ul id="progressbar">
                                                            <li className="active" />
                                                            <li />
                                                            <li />
                                                            <li />
                                                            <li />
                                                            <li />
                                                            <li />
                                                            <li />
                                                        </ul>
                                                        <fieldset>
                                                            <h2 className="fs-title">BioData</h2>
                                                            <h3 className="fs-subtitle mb-5">Your personal information</h3>
                                                            <div className="row text-left mb-5">
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">Last Name</label>
                                                                        <input className="form-control" type="text" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">First Name</label>
                                                                        <input className="form-control" type="text" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">Other Name</label>
                                                                        <input className="form-control" type="text" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">Date of Birth </label>
                                                                        <input className="form-control" type="date" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">Place of Birth </label>
                                                                        <input className="form-control" type="text" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">State of Origin </label>
                                                                        <input className="form-control" type="text" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">Phone </label>
                                                                        <input className="form-control" type="text" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <label htmlFor="text-input" className="form-control-label">Email </label>
                                                                        <input className="form-control" type="email" id="text-input" />
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <label htmlFor="text-input" className="form-control-label">Marital Status </label>
                                                                    <select className="form-control" id="text-input">
                                                                        <option>Select Status</option>
                                                                        <option>Single</option>
                                                                        <option>Married</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <input type="button" name="next" className="next action-button" defaultValue="Next" />
                                                        </fieldset>
                                                        <Education />
                                                        <ProfessionalBody />
                                                        <Journals />
                                                        <WorkExperience />
                                                        <Research />
                                                        <Certication />
                                                        <Referee />
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        )
    }
}